import 'dart:convert';

List<ModelIncomingData> ModelIncomingDataFromJson(String str) =>
    List<ModelIncomingData>.from(
        json.decode(str).map((x) => ModelIncomingData.fromJson(x)));

String ModelIncomingDataToJson(List<ModelIncomingData> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelIncomingData {
  ModelIncomingData({
    this.Id,
    this.MaterialCode,
    this.PicCode,
    this.CodeName,
    this.ProductName,
    this.Manufacturer,
    this.Package,
    this.NetWeight,
    this.Unit,
    this.Type,
    this.NumPack,
    this.Remark,
    this.Receivedate,
    this.ReceiveTime,
    this.ExpireDate,
    this.ProductNameCheck,
    this.LotCheck,
    this.ExpireCheck,
    this.PictrogramCheck,
    this.SummaryCheck,
    this.RemarkCheck,
    this.MaterialName,
    this.LotNo,
    this.FifoCheck,
    this.Location,
    this.PackSizeCheck,
    this.AppearanceCheck,
    this.PicPath,
    this.UserCheck,
  });

  dynamic Id;
  dynamic MaterialCode;
  dynamic PicCode;
  dynamic CodeName;
  dynamic ProductName;
  dynamic Manufacturer;
  dynamic Package;
  dynamic NetWeight;
  dynamic Unit;
  dynamic Type;
  dynamic NumPack;
  dynamic Remark;
  dynamic Receivedate;
  dynamic ReceiveTime;
  dynamic ExpireDate;
  dynamic ProductNameCheck;
  dynamic LotCheck;
  dynamic ExpireCheck;
  dynamic PictrogramCheck;
  dynamic SummaryCheck;
  dynamic RemarkCheck;
  //---//
  dynamic MaterialName;
  dynamic LotNo;
  dynamic FifoCheck;
  dynamic Location;
  dynamic PackSizeCheck;
  dynamic AppearanceCheck;
  dynamic PicPath;
  dynamic UserCheck;

  factory ModelIncomingData.fromJson(Map<String, dynamic> json) =>
      ModelIncomingData(
        Id: json["Id"] ?? "",
        MaterialCode: json["MaterialCode"] ?? "",
        PicCode: json["PicCode"] ?? "",
        CodeName: json["CodeName"] ?? "",
        ProductName: json["ProductName"] ?? "",
        Manufacturer: json["Manufacturer"] ?? "",
        Package: json["Package"] ?? "",
        NetWeight: json["NetWeight"] ?? "",
        Unit: json["Unit"] ?? "",
        Type: json["Type"] ?? "",
        NumPack: json["NumPack"] ?? "",
        Remark: json["Remark"] ?? "",
        Receivedate: json["Receivedate"] ?? "",
        ReceiveTime: json["ReceiveTime"] ?? "",
        ExpireDate: json["ExpireDate"] ?? "",
        ProductNameCheck: json["ProductNameCheck"] ?? "",
        LotCheck: json["LotCheck"] ?? "",
        ExpireCheck: json["ExpireCheck"] ?? "",
        PictrogramCheck: json["PictrogramCheck"] ?? "",
        SummaryCheck: json["SummaryCheck"] ?? "",
        RemarkCheck: json["RemarkCheck"] ?? "",
        MaterialName: json["MaterialName"] ?? "",
        LotNo: json["LotNo"] ?? "",
        FifoCheck: json["FifoCheck"] ?? "",
        Location: json["Location"] ?? "",
        PackSizeCheck: json["PackSizeCheck"] ?? "",
        AppearanceCheck: json["AppearanceCheck"] ?? "",
        PicPath: json["PicPath"] ?? "",
        UserCheck: json["UserCheck"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "Id": Id ?? "",
        "MaterialCode": MaterialCode ?? "",
        "PicCode": PicCode ?? "",
        "CodeName": CodeName ?? "",
        "ProductName": ProductName ?? "",
        "Manufacturer": Manufacturer ?? "",
        "Package": Package ?? "",
        "NetWeight": NetWeight ?? "",
        "Unit": Unit ?? "",
        "Type": Type ?? "",
        "NumPack": NumPack ?? "",
        "Remark": Remark ?? "",
        "Receivedate": Receivedate ?? "",
        "ReceiveTime": ReceiveTime ?? "",
        "ExpireDate": ExpireDate ?? "",
        "ProductNameCheck": ProductNameCheck ?? "",
        "LotCheck": LotCheck ?? "",
        "ExpireCheck": ExpireCheck ?? "",
        "PictrogramCheck": PictrogramCheck ?? "",
        "SummaryCheck": SummaryCheck ?? "",
        "RemarkCheck": RemarkCheck ?? "",
        "MaterialName": MaterialName ?? "",
        "LotNo": LotNo ?? "",
        "FifoCheck": FifoCheck ?? "",
        "Location": Location ?? "",
        "PackSizeCheck": PackSizeCheck ?? "",
        "AppearanceCheck": AppearanceCheck ?? "",
        "PicPath": PicPath ?? "",
        "UserCheck": UserCheck ?? "",
      };
}
