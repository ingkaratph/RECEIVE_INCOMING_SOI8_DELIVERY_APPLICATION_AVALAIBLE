import 'package:flutter/cupertino.dart';

const url = 'http://172.23.10.51:1889';

//Login
String GloUserID = '';
String GloPassword = '';
String userName = '';
String userSection = '';
String userBranch = '';
int userRoleId = 0;
String currentPage = "";
String lastPage = "";
String buffferLastPage = "";
String alertText = "";
int timeOut = 30;

late BuildContext contextBG;
