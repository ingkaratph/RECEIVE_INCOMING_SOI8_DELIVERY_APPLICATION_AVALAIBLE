import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:standard_package_rm/Global/global_var.dart';
import 'package:standard_package_rm/Page/0LoginPage/LoginPage.dart';
import 'package:standard_package_rm/Page/StdIncomingData/Incoming_Detail.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    contextBG = context;
    return WillPopScope(
      onWillPop: () async => blockBack(),
      child: MaterialApp(
        builder: EasyLoading.init(),
        scrollBehavior: MyCustomScrollBehavior(),
        title: 'SOI8_ReceiveFG',
        theme: ThemeData(
          fontFamily: 'Mitr',
          primarySwatch: Colors.blueGrey,
        ),
        debugShowCheckedModeBanner: false,
        home: LoginPage(),
      ),
    );
  }
}

// BlocPageRebuild blocPageRebuild = BlocProvider.of<BlocPageRebuild>(context).rebuildPage();

class MyCustomScrollBehavior extends MaterialScrollBehavior {
  // Override behavior methods and getters like dragDevices
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        // etc.
      };
}

Future<bool> blockBack() async {
  /* Navigator.pop(contextBG);
        BlocProvider.of<SwPageCubit>(contextBG).togglePage(lastPage); */
  return true;
}
