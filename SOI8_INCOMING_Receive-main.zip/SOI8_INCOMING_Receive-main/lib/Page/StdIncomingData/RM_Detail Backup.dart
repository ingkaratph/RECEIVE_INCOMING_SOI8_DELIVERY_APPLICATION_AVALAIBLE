/* import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:csv/csv.dart';
import 'package:standard_package_rm/global_var.dart';
import 'package:card_swiper/card_swiper.dart';

Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

class rm_deatil extends StatefulWidget {
  const rm_deatil({Key? key}) : super(key: key);

  @override
  State<rm_deatil> createState() => _rm_deatilState();
}

String pathCSV = "";
List<ModelIncomingData> csvData = [];

class _rm_deatilState extends State<rm_deatil> {
  @override
  void initState() {
    print("InINITIAL State");
    readPref();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void readPref() async {
    print('inread pref');
    final SharedPreferences prefs = await _prefs;
    pathCSV = (prefs.getString('pathCSV') ?? '');
    print('pathinpre : ' + pathCSV);
    if (pathCSV != '') {
      //readExcel();
      readCSV();
    }
    print('pathinpre : ' + pathCSV);
  }

  Future<void> choseFile(int num) async {
    final SharedPreferences prefs = await _prefs;
    try {
      FilePickerResult? pickedFile;
      if (num == 1) {
        pickedFile = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['csv'],
          allowMultiple: false,
        );
      } else {
        pickedFile = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['png'],
          allowMultiple: false,
        );
      }
      print("debug1");

      /// file might be picked
      if (pickedFile != null) {
        print("debug2");
        pickedFile.files;
        pathCSV = pickedFile.paths[0] as String;
        //pickedFile.paths.getFilesDir();
        print("path : " + pathCSV);
        //var bytes = pickedFile.files.single.bytes;
        prefs.setString("pathCSV", pathCSV);
        //readExcel();
        readCSV();
      } else {
        print("debug3");
        //pathExcel = 'error';
        setState(() {});
      }
    } on Error catch (e) {
      print(e);
    }
  }

  void readCSV() {
    /* print('inreadcsv');
    print('pathexcel:' + pathCSV); */
    openFile(pathCSV);
  }

  openFile(filepath) async {
    File f = new File(filepath);
    /* print("CSV to List"); */
    final input = f.openRead();
    final fields = await input
        .transform(utf8.decoder)
        .transform(new CsvToListConverter())
        .toList();
/*     print(fields.length);
    print(fields);
    print(fields[0][0]); */
    csvData.clear();
    for (var i = 0; i < fields.length; i++) {
      csvData.add(ModelIncomingData(
        //Bc: fields[i][0],
        PicCode: fields[i][1],
        CodeName: fields[i][2],
        ProductName: fields[i][3],
        Manufacturer: fields[i][4],
        Package: fields[i][5],
        //Size: fields[i][6],
        Unit: fields[i][7],
        Remark: fields[i][8],
      ));
      /* csvData.add(ModelIncomingData(
        Id: fields[i][0],
        Newno: fields[i][1],
        Bc: fields[i][2],
        ProductName: fields[i][3],
        CodeName: fields[i][4],
        PicCode: fields[i][5],
        ExpireDateDefault: fields[i][6],
        Manufacturer: fields[i][7],
        Package: fields[i][8],
        Size: fields[i][9],
        Unit: fields[i][10],
        Type: fields[i][11],
        NumPack: fields[i][12],
        Remark: fields[i][13],
        Receivedate: fields[i][14],
        ReceiveTime: fields[i][15],
        ExpireDate: fields[i][16],
      )); */
    }
    csvData.removeAt(0);
    csvToDataSelectd();
    setState(() {});
  }

  csvToDataSelectd() {
    dataSelectd.clear();
    for (var i = 0; i < csvData.length; i++) {
      dataSelectd.add(ModelIncomingData(
        Id: csvData[i].Id,
        //Newno: csvData[i].Newno,
       // Bc: csvData[i].Bc,
        ProductName: csvData[i].ProductName,
        CodeName: csvData[i].CodeName,
        PicCode: csvData[i].PicCode,
       // ExpireDateDefault: csvData[i].ExpireDateDefault,
        Manufacturer: csvData[i].Manufacturer,
        Package: csvData[i].Package,
        //Size: csvData[i].Size,
        Unit: csvData[i].Unit,
        Type: csvData[i].Type,
        NumPack: csvData[i].NumPack,
        Remark: csvData[i].Remark,
        Receivedate: csvData[i].Receivedate,
        ReceiveTime: csvData[i].ReceiveTime,
        ExpireDate: csvData[i].ExpireDate,
      ));
    }
  }

/*   searchData(String receiveTag) {
    dataSelectd.clear();
    var buffRec = '';
    for (int i = 0; i < csvData.length; i++) {
      if (receiveTag.length > 8) {
        buffRec = receiveTag.substring(0, 8);
      } else {
        buffRec = receiveTag;
      }
      /*  print("receive :" + receiveTag);
      print("BC :" + csvData[i].Bc.toString());
      print("buff : " + buffRec);
      print("CodeName : " + csvData[i].CodeName);
       print("Pd Name : " + csvData[i].ProductName); */

      //print(csvData[i].Bc.toString());
      if ((csvData[i].Bc.toString()).contains(buffRec)) {
        print('true + {$i}');
        dataSelectd.add(ModelIncomingData(
          Id: csvData[i].Id,
          Newno: csvData[i].Newno,
          Bc: csvData[i].Bc,
          ProductName: csvData[i].ProductName,
          CodeName: csvData[i].CodeName,
          PicCode: csvData[i].PicCode,
          ExpireDateDefault: csvData[i].ExpireDateDefault,
          Manufacturer: csvData[i].Manufacturer,
          Package: csvData[i].Package,
          Size: csvData[i].Size,
          Unit: csvData[i].Unit,
          Type: csvData[i].Type,
          NumPack: csvData[i].NumPack,
          Remark: csvData[i].Remark,
          Receivedate: csvData[i].Receivedate,
          ReceiveTime: csvData[i].ReceiveTime,
          ExpireDate: csvData[i].ExpireDate,
        ));
      } else if ((csvData[i].CodeName.toString().toLowerCase())
          .contains(receiveTag.toLowerCase())) {
        print('true + {$i}');
        dataSelectd.add(ModelIncomingData(
          Id: csvData[i].Id,
          Newno: csvData[i].Newno,
          Bc: csvData[i].Bc,
          ProductName: csvData[i].ProductName,
          CodeName: csvData[i].CodeName,
          PicCode: csvData[i].PicCode,
          ExpireDateDefault: csvData[i].ExpireDateDefault,
          Manufacturer: csvData[i].Manufacturer,
          Package: csvData[i].Package,
          Size: csvData[i].Size,
          Unit: csvData[i].Unit,
          Type: csvData[i].Type,
          NumPack: csvData[i].NumPack,
          Remark: csvData[i].Remark,
          Receivedate: csvData[i].Receivedate,
          ReceiveTime: csvData[i].ReceiveTime,
          ExpireDate: csvData[i].ExpireDate,
        ));
      } else if ((csvData[i].ProductName.toString().toLowerCase())
          .contains(receiveTag.toLowerCase())) {
        print('true + {$i}');
        dataSelectd.add(ModelIncomingData(
          Id: csvData[i].Id,
          Newno: csvData[i].Newno,
          Bc: csvData[i].Bc,
          ProductName: csvData[i].ProductName,
          CodeName: csvData[i].CodeName,
          PicCode: csvData[i].PicCode,
          ExpireDateDefault: csvData[i].ExpireDateDefault,
          Manufacturer: csvData[i].Manufacturer,
          Package: csvData[i].Package,
          Size: csvData[i].Size,
          Unit: csvData[i].Unit,
          Type: csvData[i].Type,
          NumPack: csvData[i].NumPack,
          Remark: csvData[i].Remark,
          Receivedate: csvData[i].Receivedate,
          ReceiveTime: csvData[i].ReceiveTime,
          ExpireDate: csvData[i].ExpireDate,
        ));
      }
    }
    print(dataSelectd);
    setState(() {});
  } */

  clearData() {
    csvToDataSelectd();
    setState(() {});
  }

  TextStyle styleHeader = const TextStyle(
      fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Mitr');
  TextStyle styleData = const TextStyle(
      fontSize: 14, fontWeight: FontWeight.normal, fontFamily: 'Mitr');
  /* void readExcel() {
    if (pathExcel != '') {
      try {
        var bytes = File(pathExcel).readAsBytesSync(); //อันนี้ใช้ได้
        var excel = Excel.decodeBytes(bytes);
        var table2 = excel.tables.keys;
        /* print('table : ' + table2.toString()); //sheet Name
        print('max col : ' + (excel.tables['data']?.maxCols).toString());
        print('max row : ' + (excel.tables[table2]?.maxRows).toString()); */
        for (var table in excel.tables.keys) {
          print(table); //sheet Name
          print(excel.tables[table]?.maxCols);
          print(excel.tables[table]?.maxRows);
          for (var row in excel.tables[table]!.rows) {
            //print("$row");
          }

          Sheet sheetObject = excel[table2.toString()];
          var cell = sheetObject.cell(CellIndex.indexByString("A2"));
          print(cell.value);
        }
        var sheet = excel[table2.toString()];
        for (int row = 0; row < sheet.maxRows; row++) {
          sheet.row(row).forEach((cell) {
            var val = cell?.value; //  Value stored in the particular cell
            print('$val');
            cell?.value = ' My custom Value ';
          });
        }
        /* for (var table in excel.tables.keys) {
          for (var row in excel.tables[table]!.rows) {
            print("$row");
            excelData = row;
            setState(() {});
          }
        } */
      } on Exception catch (e) {
        print('error' + e.toString());
        // TODO
      }
    } else {
      CoolAlert.show(
        width: 150,
        context: context,
        type: CoolAlertType.error,
        title: 'ERROR',
        text: 'NOT FOUND DATA',
        loopAnimation: false,
      );
    }
  } */
  double swiperHeight = 700;
  double swiperWidth = 450;
  List<ModelIncomingData> dataSelectd = [];
  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
    // pathExcel = "/data/user/0/com.example.standard_package_rm/cache/file_picker/test.xlsx";
    //choseFile();
    /* pathExcel = "/storage/F0E9-334E/RM_Data/test.xlsx";
    print("name" + pathExcel);
    //var file = "Path_to_pre_existing_Excel_File/excel_file.xlsx";
    if (pathExcel != '') {
      print(pathExcel);
      var bytes = File(pathExcel).readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);
      print("table");
      for (var table in excel.tables.keys) {
        print(table); //sheet Name
        print(excel.tables[table]?.maxCols);
        print(excel.tables[table]!.maxRows);
        for (var row in excel.tables[table]!.rows) {
          print("$row");
        }
      }
    } */

    return MaterialApp(
      scaffoldMessengerKey: _scaffoldMessengerKey,
      home: Scaffold(
          key: _scaffoldKey,
          /* appBar: AppBar(
            title: const Text('Std RM Package'),
          ), */
          body: Container(
            margin: const EdgeInsets.only(
              top: 5,
            ),
            child: SingleChildScrollView(
              child: Column(
                //mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  /* ElevatedButton(
                    onPressed: () => choseFile(1),
                    child: Text(pathCSV),
                  ), */
                  /* ElevatedButton(
                    onPressed: () => choseFile(2),
                    child: Text(pathCSV),
                  ), */
                  if (dataSelectd.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(
                          left: 25, right: 25, top: 20, bottom: 15),
                      width: swiperWidth,
                      height: swiperHeight,
                      //color: Colors.red,
                      child: Swiper(
                        loop: false,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 15),
                                Container(
                                  width: swiperWidth,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      GestureDetector(
                                        child: Container(
                                          //color: Colors.amber,
                                          //width: swiperWidth - 20,
                                          height: 300,
                                          child: Center(
                                            child: Image.file(
                                              File(
                                                  '/storage/F0E9-334E/rm-data/images/' +
                                                      dataSelectd[index]
                                                          .PicCode
                                                          .toString() +
                                                      '.png'),
                                            ),
                                            /*  File(
                                                  '/storage/F0E9-334E/data_rm/images/130000901.png'),
                                            ), */
                                            /* File(
                                                  '/data/user/0/com.example.standard_package_rm/cache/file_picker/130000901.png'),
                                            ),  */
                                          ),
                                        ),
                                        onTap: () {
                                          print('tap');
                                          showPicZoom(
                                              '/storage/F0E9-334E/rm-data/images/' +
                                                  dataSelectd[index]
                                                      .PicCode
                                                      .toString() +
                                                  '.png');
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    Text(
                                      'MATERIAL CODE',
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        'dataSelectd[index].Bc.toString()',
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                                space(),
                                Row(
                                  children: [
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        'CODE NAME',
                                        style: styleHeader,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        dataSelectd[index].CodeName.toString(),
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                                /* space(),
                                Text(
                                  'EXPIRE DATE',
                                  style: styleHeader,
                                ),
                                Text(
                                  dataSelectd[index].ExpireDateDefault.toString(),
                                  style: styleData,
                                ), */
                                space(),
                                Row(
                                  children: [
                                    spaceHor(),
                                    Text(
                                      'PRODUCT NAME',
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        dataSelectd[index]
                                            .ProductName
                                            .toString(),
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                                space(),
                                Row(
                                  children: [
                                    spaceHor(),
                                    Text(
                                      'MANUFACTURER',
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        dataSelectd[index]
                                            .Manufacturer
                                            .toString(),
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                                space(),
                                Row(
                                  children: [
                                    spaceHor(),
                                    Text(
                                      'PACKAGING',
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        'dataSelectd[index].Size.toString()' +
                                            ' ' +
                                            dataSelectd[index].Unit.toString() +
                                            ' / ' +
                                            dataSelectd[index]
                                                .Package
                                                .toString(),
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                                /* space(),
                                Text(
                                  'NUM PACK',
                                  style: styleHeader,
                                ),
                                Text(
                                  dataSelectd[index].NumPack.toString(),
                                  style: styleData,
                                ), */
                                space(),
                                Row(
                                  children: [
                                    spaceHor(),
                                    Text(
                                      'REMARK',
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    spaceHor(),
                                    spaceHor(),
                                    SizedBox(
                                      width: textboxSize,
                                      child: Text(
                                        dataSelectd[index].Remark.toString(),
                                        style: styleData,
                                        maxLines: null,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                        itemCount: dataSelectd.length,
                        pagination: const FractionPaginationBuilder(
                            fontSize: 15,
                            color: Colors.black,
                            activeFontSize: 15,
                            activeColor: Colors.black),
                        control: const SwiperControl(),
                      ),
                    ),
                  if (dataSelectd.isEmpty)
                    Container(
                      margin: const EdgeInsets.only(
                          left: 25, right: 25, top: 25, bottom: 15),
                      width: swiperWidth,
                      height: swiperHeight,
                      child: const Text('NOT FOUND DATA',
                          style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'Mitr')),
                    ),
                ],
              ),
            ),
          ),
          floatingActionButton: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                FloatingActionButton(
                  child: Icon(Icons.file_open),
                  onPressed: () {
                    choseFile(1);
                  },
                  heroTag: null,
                ),
                const SizedBox(
                  height: 10,
                ),
                FloatingActionButton(
                  child: Icon(Icons.clear),
                  onPressed: () {
                    clearData();
                    //_formKey.currentState?.reset();
                  },
                  heroTag: const Text('Test'),
                ),
                const SizedBox(
                  height: 10,
                ),
                FloatingActionButton(
                  child: const Icon(Icons.search),
                  onPressed: () {
                    inputTag();
                  },
                  heroTag: null,
                ),
              ])),
    );
  }

  SizedBox space() {
    return const SizedBox(
      height: 4,
    );
  }

  SizedBox spaceHor() {
    return const SizedBox(
      width: 25,
    );
  }

  Future<void> inputTag() {
    late FocusNode myFocusNode;
    myFocusNode = FocusNode();
    myFocusNode.requestFocus();
    return showDialog(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                'SEARCH DATA',
                style: styleHeader,
              ),
              Form(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    width: 200,
                    child: TextField(
                      focusNode: myFocusNode,
                      textInputAction: TextInputAction.done,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'แสกน หรือ พิมพ์',
                      ),
                      onSubmitted: (val) {
                        Navigator.of(context).pop();
                        /* searchData(val.toString()); */
                      },
                    ),
                  ),
                ],
              ))
            ],
          ), /* 
          actions: <Widget>[
            TextButton(
              child: const Text('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ], */
        );
      },
    );
  }

  double textboxSize = 200;

  Future<void> showPicZoom(String pic) {
    return showDialog(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: InteractiveViewer(
            //boundaryMargin: const EdgeInsets.all(20.0),
            //clipBehavior: Clip.none,
            //panEnabled: true,
            minScale: 1,
            maxScale: 4,
            child: Container(
              alignment: FractionalOffset.center,
              height: 1000,
              width: 550,
              padding: const EdgeInsets.all(20.0),
              child: SizedBox(
                //color: Colors.amber,
                /* width: 500,
                  height: 500, */
                child: Image.file(
                  File(pic),
                ),
              ),
            ),
          ),
        ); /* AlertDialog(
          content: Container(
            //height: 800,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                InteractiveViewer(
                  //boundaryMargin: const EdgeInsets.all(20.0),
                  //clipBehavior: Clip.none,
                  //panEnabled: true,
                  minScale: 1,
                  maxScale: 3,
                  child: SizedBox(
                    //color: Colors.amber,
                    width: 500,
                    height: 500,
                    child: Image.file(
                      File(pic),
                    ),
                  ),
                ),
              ],
            ),
          ), /* 
          actions: <Widget>[
            TextButton(
              child: const Text('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ], */
        ); */
      },
    );
  }
}
 */