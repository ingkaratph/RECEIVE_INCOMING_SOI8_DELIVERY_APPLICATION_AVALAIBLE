import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
//----------------------------------------------------------------
import 'package:http/http.dart' as http;
import 'package:standard_package_rm/Global/global_var.dart';
import 'package:standard_package_rm/global_var.dart';

abstract class RM_DetailEvent {}

class FetchincomingData extends RM_DetailEvent {}

class SearchincomingData extends RM_DetailEvent {}

// ignore: camel_case_types
class ManageDataIncoming_Detail
    extends Bloc<RM_DetailEvent, List<ModelIncomingData>> {
  ManageDataIncoming_Detail() : super([ModelIncomingData()]) {
    //on<ClearState>((event, emit) => _ClearState(>));]

    // ignore: void_checks
    on<FetchincomingData>((event, emit) {
      return _FetchincomingData(event, emit);
    });
    // ignore: void_checks
    on<SearchincomingData>((event, emit) {
      return _SearchincomingData(event, emit);
    });
  }
}

List<ModelIncomingData> incomingData = [];
// ignore: non_constant_identifier_names
Future<List<ModelIncomingData>> _FetchincomingData(event, emit) async {
  print('in Fetch data');
  Map<String, String> qParams = {
    // 'reqNo': reqNo,
  };
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_FetchincomingData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    if (response.statusCode == 200) {
      incomingData = ModelIncomingDataFromJson(response.body);
      emit(incomingData);
      return incomingData;
    } else {
      emit(incomingData);
      return incomingData;
    }
  } on TimeoutException catch (e) {
    print(e);
    emit(incomingData);
    return incomingData;
  } on Error catch (e) {
    print(e);
    emit(incomingData);
    return incomingData;
  }
}

String SearchOption = "";

Future<List<ModelIncomingData>> _SearchincomingData(event, emit) async {
  print('in SearchincomingData data');
  Map<String, String> qParams = {
    'SearchOption': SearchOption,
  };
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_SearchincomingData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    if (response.statusCode == 200) {
      print('in2');
      incomingData = ModelIncomingDataFromJson(response.body);
      emit(incomingData);
      return incomingData;
    } else {
      return incomingData;
    }
  } on TimeoutException catch (e) {
    return incomingData;
  } on Error catch (e) {
    return incomingData;
  }
}

String picture = "";
Future getPicture(String path) async {
  Map<String, String> qParams = {
    'path': path,
  };
  print("in searchPicture $path");
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_LoadPicture"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      picture = response.body;
      print("in searchPicture response complete");
      return 1;
    } else {
      print("where is my server");
      return 0;
    }
  } catch (e) {
    print(e);
  }
}

List<ModelIncomingData> accpetData = [];

Future saveAcceptRawMat() async {
  Map<String, String> qParams = {
    'user': userName,
    'accpetData': ModelIncomingDataToJson(accpetData),
  };
  print("in saveAcceptRawMat ");
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_saveAcceptRawMat"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      picture = response.body;
      print("in SaveRecheckData response complete");
      return 1;
    } else {
      print("where is my server");
      return 0;
    }
  } catch (e) {
    print(e);
  }
}

List<ModelIncomingData> rejectData = [];

Future saveRejectRawMat() async {
  Map<String, String> qParams = {
    'user': userName,
    'rejectData': ModelIncomingDataToJson(rejectData),
  };
  print("in saveRejectRawMat ");
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_saveRejectRawMat"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      picture = response.body;
      print("in SaveRecheckData response complete");
      return 1;
    } else {
      print("where is my server");
      return 0;
    }
  } catch (e) {
    print(e);
  }
}
