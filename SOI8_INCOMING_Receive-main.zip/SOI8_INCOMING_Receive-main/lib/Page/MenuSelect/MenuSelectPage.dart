import 'dart:convert';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:standard_package_rm/Page/App_Bar/App_Bar.dart';
import 'package:standard_package_rm/Page/MenuSelect/data/MenuSelectPage_Data.dart';
import 'package:standard_package_rm/Page/ReceiveFG/ReceiveFG.dart';
import 'package:standard_package_rm/Page/StdIncomingData/Incoming_Detail.dart';

late BuildContext context_MenuSelectPage;

class MenuSelectPage extends StatelessWidget {
  const MenuSelectPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
    context_MenuSelectPage = context;
    return MaterialApp(
        scaffoldMessengerKey: _scaffoldMessengerKey,
        home: Scaffold(
            appBar: AppBar(
              backgroundColor: const Color(0xFF0b1327),
              actions: <Widget>[App_Bar()],
            ),
            key: _scaffoldKey,
            body: SingleChildScrollView(
              child: Container(
                width: 500,
                margin: const EdgeInsets.only(top: 25, left: 5, right: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      width: 200,
                      height: 170,
                      child: InkWell(
                        onTap: () {
                          inputTag();
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.save,
                              color: Colors.green,
                              size: 100.0,
                            ),
                            Text('ลงข้อมูลการรับงาน'),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      width: 200,
                      height: 170,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Incoming_Detail()),
                          );
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.search,
                              color: Colors.black12,
                              size: 100.0,
                            ),
                            Text('เช็คมาตราฐานงาน'),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      width: 200,
                      height: 170,
                      child: InkWell(
                        onTap: () {},
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.dataset_rounded,
                              color: Colors.yellow,
                              size: 100.0,
                            ),
                            Text('เช็คข้อมูลการรับงาน'),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )));
  }
}

Future<void> inputTag() {
  late FocusNode myFocusNode;
  myFocusNode = FocusNode();
  myFocusNode.requestFocus();
  return showDialog(
    context: context_MenuSelectPage,
    barrierDismissible: true, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              'SEARCH DATA',
              //style: styleHeader,
            ),
            Form(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 30,
                ),
                SizedBox(
                  width: 200,
                  child: TextField(
                    focusNode: myFocusNode,
                    textInputAction: TextInputAction.done,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'แสกน หรือ พิมพ์',
                    ),
                    onSubmitted: (val) async {
                      SearchOption = val.toString();
                      await SearchincomingData();
                      if (itemData.length != 0) {
                        Navigator.of(context).pop();
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ReceiveFG()),
                        );
                      } else {
                        Navigator.of(context).pop();
                        CoolAlert.show(
                          barrierDismissible: true,
                          width: 200,
                          context: context,
                          type: CoolAlertType.error,
                          text: 'ไม่พบข้อมูล',
                          /* confirmBtnText: 'Yes',
                          loopAnimation: true,
                          showCancelBtn: true,
                          confirmBtnColor: Colors.green,
                          onCancelBtnTap: () {
                            Navigator.pop(context);
                          }, */
                        );
                      }
                    },
                  ),
                ),
              ],
            ))
          ],
        ),
      );
    },
  );
}

double textboxSize = 200;
