import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
//----------------------------------------------------------------
import 'package:http/http.dart' as http;
import 'package:standard_package_rm/Global/global_var.dart';
import 'package:standard_package_rm/global_var.dart';

List<ModelIncomingData> itemData = [];
String SearchOption = "";

Future<List<ModelIncomingData>> SearchincomingData() async {
  print('in SearchincomingData data');
  Map<String, String> qParams = {
    'SearchOption': SearchOption,
  };
  try {
    itemData.clear();
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_SearchItemData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    if (response.statusCode == 200) {
      itemData = ModelIncomingDataFromJson(response.body);
      itemData[0].UserCheck = userName;
      return itemData;
    } else {
      return itemData;
    }
  } on TimeoutException catch (e) {
    return itemData;
  } on Error catch (e) {
    return itemData;
  }
}
