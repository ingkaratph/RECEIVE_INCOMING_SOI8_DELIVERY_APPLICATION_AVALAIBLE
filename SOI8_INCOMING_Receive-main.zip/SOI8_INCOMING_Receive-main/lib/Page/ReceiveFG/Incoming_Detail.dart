import 'dart:convert';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:standard_package_rm/Page/App_Bar/App_Bar.dart';
import 'package:standard_package_rm/Page/StdIncomingData/data/Incoming_DetailData.dart';
import 'package:standard_package_rm/global_var.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';

late BuildContext contextincoming_deatil;

class Incoming_Detail extends StatelessWidget {
  const Incoming_Detail({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ManageDataIncoming_Detail>(
          create: (BuildContext context) => ManageDataIncoming_Detail(),
        ),
      ],
      child: incoming_deatil(),
    );
  }
}

class incoming_deatil extends StatefulWidget {
  const incoming_deatil({Key? key}) : super(key: key);

  @override
  State<incoming_deatil> createState() => _incoming_deatilState();
}

String pathCSV = "";
List<ModelIncomingData> csvData = [];

TextStyle styleHeader = const TextStyle(
    fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Mitr');
TextStyle styleData = const TextStyle(
    fontSize: 14, fontWeight: FontWeight.normal, fontFamily: 'Mitr');

double swiperHeight = 850;
double swiperWidth = 450;

class _incoming_deatilState extends State<incoming_deatil> {
  @override
  void initState() {
    super.initState();
    print('in int');
    context.read<ManageDataIncoming_Detail>().add(FetchincomingData());
  }

  @override
  void dispose() {
    super.dispose();
  }

  void acceptRawMat() {
    CoolAlert.show(
      barrierDismissible: true,
      width: 200,
      context: context,
      type: CoolAlertType.success,
      text: 'Raw material ไม่มีปัญหา',
      confirmBtnText: 'Yes',
      cancelBtnText: 'No',
      loopAnimation: true,
      showCancelBtn: true,
      confirmBtnColor: Colors.green,
      widget: TextField(
        decoration: const InputDecoration(
            contentPadding: EdgeInsets.all(10.0), border: OutlineInputBorder()),
        onChanged: (value) {},
      ),
      onConfirmBtnTap: () {
        saveAcceptRawMat();
        Navigator.pop(context);
      },
      onCancelBtnTap: () {
        Navigator.pop(context);
      },
    );
  }

  void rejectRawMat() {
    CoolAlert.show(
      barrierDismissible: true,
      width: 200,
      context: context,
      type: CoolAlertType.warning,
      text: 'Raw material มีปัญหา',
      confirmBtnText: 'Yes',
      cancelBtnText: 'No',
      loopAnimation: true,
      showCancelBtn: true,
      confirmBtnColor: Colors.amber,
      widget: TextField(
        decoration: const InputDecoration(
            contentPadding: EdgeInsets.all(10.0), border: OutlineInputBorder()),
        onChanged: (value) {},
      ),
      onConfirmBtnTap: () {
        saveRejectRawMat();
        Navigator.pop(context);
      },
      onCancelBtnTap: () {
        Navigator.pop(context);
      },
    );
  }

  final _formKey = GlobalKey<FormBuilderState>();
  @override
  Widget build(BuildContext context) {
    //contextincoming_deatil = context;
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
    contextincoming_deatil = context;
    return MaterialApp(
      scaffoldMessengerKey: _scaffoldMessengerKey,
      home: Scaffold(
          appBar: AppBar(
            backgroundColor: const Color(0xFF0b1327),
            actions: <Widget>[App_Bar()],
          ),
          key: _scaffoldKey,
          body: Container(
            margin: const EdgeInsets.only(
              top: 5,
            ),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: BlocBuilder<ManageDataIncoming_Detail,
                    List<ModelIncomingData>>(builder: (context, state) {
                  print(incomingData.length);
                  return Column(
                    children: [
                      if (incomingData.isNotEmpty)
                        Container(
                          margin: const EdgeInsets.only(
                              left: 25, right: 25, top: 20, bottom: 15),
                          width: swiperWidth,
                          height: swiperHeight,
                          //color: Colors.red,
                          child: Swiper(
                            loop: true,
                            duration: 10,
                            autoplayDelay: 1000,
                            index: 0,
                            itemBuilder: (BuildContext context, int index) {
                              return Container(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 15),
                                    SizedBox(
                                      width: swiperWidth,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          GestureDetector(
                                            child: Container(
                                              //color: Colors.amber,
                                              //width: swiperWidth - 20,
                                              height: 300,
                                              child: Center(
                                                  child: ShowPicture(
                                                      path: incomingData[index]
                                                          .PicCode
                                                          .toString())),
                                            ),
                                            onTap: () {
                                              showPicZoom(picture);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          'MATERIAL CODE',
                                          style: styleHeader,
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          //width: textboxSize,
                                          child: Text(
                                            incomingData[index]
                                                .MaterialCode
                                                .toString(),
                                            style: styleData,
                                            maxLines: null,
                                          ),
                                        ),
                                      ],
                                    ),
                                    space(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          //width: textboxSize,
                                          child: Text(
                                            'CODE NAME',
                                            style: styleHeader,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          // width: textboxSize,
                                          child: Text(
                                            incomingData[index]
                                                .CodeName
                                                .toString(),
                                            style: styleData,
                                            maxLines: null,
                                          ),
                                        ),
                                      ],
                                    ),
                                    space(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          'PRODUCT NAME',
                                          style: styleHeader,
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          //width: textboxSize,
                                          child: Text(
                                            incomingData[index]
                                                .ProductName
                                                .toString(),
                                            style: styleData,
                                            maxLines: null,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                            itemCount: incomingData.length,
                            pagination: const FractionPaginationBuilder(
                                fontSize: 15,
                                color: Colors.black,
                                activeFontSize: 15,
                                activeColor: Colors.black),
                            control: const SwiperControl(),
                          ),
                        ),
                      if (incomingData.isEmpty)
                        Container(
                          margin: const EdgeInsets.only(
                              left: 25, right: 25, top: 25, bottom: 15),
                          width: swiperWidth,
                          height: swiperHeight,
                          child: const Text('NOT FOUND DATA',
                              style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'Mitr')),
                        ),
                    ],
                  );
                }),
              ),
            ),
          ),
          floatingActionButton: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
/*                 FloatingActionButton(
                  child: Icon(Icons.file_open),
                  onPressed: () {},
                  heroTag: null,fl
                ),
                const SizedBox(
                  height: 10,
                ), */
                FloatingActionButton(
                  child: Icon(Icons.clear),
                  onPressed: () {
                    contextincoming_deatil
                        .read<ManageDataIncoming_Detail>()
                        .add(FetchincomingData());
                  },
                  heroTag: const Text('Test'),
                ),
                const SizedBox(
                  height: 10,
                ),
                FloatingActionButton(
                  child: const Icon(Icons.search),
                  onPressed: () {
                    inputTag();
                  },
                  heroTag: null,
                ),
              ])),
    );
  }

  SizedBox space() {
    return const SizedBox(
      height: 4,
    );
  }

  SizedBox spaceHor() {
    return const SizedBox(
      width: 25,
    );
  }

  Future<void> inputTag() {
    late FocusNode myFocusNode;
    myFocusNode = FocusNode();
    myFocusNode.requestFocus();
    return showDialog(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                'SEARCH DATA',
                style: styleHeader,
              ),
              Form(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    width: 200,
                    child: TextField(
                      focusNode: myFocusNode,
                      textInputAction: TextInputAction.done,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'แสกน หรือ พิมพ์',
                      ),
                      onSubmitted: (val) {
                        SearchOption = val.toString();
                        contextincoming_deatil
                            .read<ManageDataIncoming_Detail>()
                            .add(SearchincomingData());
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                ],
              ))
            ],
          ),
        );
      },
    );
  }

  double textboxSize = 200;

  Future<void> showPicZoom(String pic) {
    return showDialog(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        var outputAsUint8List;
        outputAsUint8List = base64.decode(pic);
        return Dialog(
          backgroundColor: Colors.transparent,
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: Container(
              alignment: FractionalOffset.center,
              height: 1000,
              width: 550,
              padding: const EdgeInsets.all(20.0),
              child: SizedBox(
                child: outputAsUint8List != null
                    ? Image.memory(outputAsUint8List!,
                        //width: 250, height: 250,
                        fit: BoxFit.cover)
                    : Container(),
              ),
            ),
          ),
        );
      },
    );
  }
}

class ShowPicture extends StatefulWidget {
  String path = "";
  ShowPicture({
    required this.path,
  });

  @override
  State<StatefulWidget> createState() => ShowPictureState();
}

class ShowPictureState extends State<ShowPicture> {
  late bool isShowingMainData;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: getPicture(widget.path),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data != 0) {
              var outputAsUint8List;
              outputAsUint8List = base64.decode(picture);
              return Container(
                width: 300,
                child: outputAsUint8List != null
                    ? Image.memory(outputAsUint8List!,
                        //width: 250, height: 250,
                        fit: BoxFit.cover)
                    : Container(),
              );
            } else {
              return Text("PICTURE NOT FOUND");
            }
          } else if (snapshot.hasError) {
            return Text(snapshot.error.toString());
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        });
  }
}
/* 
class ChoiceChip extends StatefulWidget {
  int index;
  String name;
  ChoiceChip({Key? key, required this.index, required this.name})
      : super(key: key);

  @override
  State<ChoiceChip> createState() => _ChoiceChipState();
}

class _ChoiceChipState extends State<ChoiceChip> {
  @override
  Widget build(BuildContext context) {
    int index = widget.index;
    String name = widget.name;
    String status = "";
    if (name == 'PD') {
      status = incomingData[index].ProductNameCheck;
    } else if (name == 'LN') {
      status = incomingData[index].LotCheck;
    } else if (name == 'ED') {
      status = incomingData[index].ExpireCheck;
    } else if (name == 'QP') {
      status = incomingData[index].QuanityPerPackCheck;
    } else if (name == 'PT') {
      status = incomingData[index].PictrogramCheck;
    }
    return SizedBox(
      //height: 35,
      child: FormBuilderChoiceChip<String>(
        visualDensity: const VisualDensity(
          horizontal: 0,
          vertical: 0,
        ),
        //materialTapTargetSize: MaterialTapTargetSize,
        alignment: WrapAlignment.start,
        //alignment: WrapAlignment.center,
        padding: EdgeInsets.only(left: 25, right: 25),
        selectedColor: (() {
          if (status == "OK") {
            return Colors.green;
          } else {
            return Colors.red;
          }
        }()),
        labelPadding: const EdgeInsets.all(0),
        decoration: const InputDecoration(
          constraints: BoxConstraints(maxHeight: 50),
          contentPadding: EdgeInsets.all(0),
          //border: OutlineInputBorder(gapPadding: -5)
          border: InputBorder.none,
        ),
        avatarBorder: const CircleBorder(side: BorderSide.none),
        //shape: StadiumBorder(side: BorderSide()),
        name: name + index.toString(),
        spacing: 20,
        options: const [
          FormBuilderChipOption(
            value: "OK",
          ),
          FormBuilderChipOption(
            value: "NG",
          ),
          //FormBuilderChipOption(value: "NG")
        ],
        onChanged: (dynamic val) {
          if (name == 'PD') {
            incomingData[index].ProductNameCheck = val.toString();
          } else if (name == 'LN') {
            incomingData[index].LotCheck = val.toString();
          } else if (name == 'ED') {
            incomingData[index].ExpireCheck = val.toString();
          } else if (name == 'QP') {
            incomingData[index].QuanityPerPackCheck = val.toString();
          } else if (name == 'PT') {
            incomingData[index].PictrogramCheck = val.toString();
          }

          setState(() {});
        },
      ),
    );
  }
}
 */