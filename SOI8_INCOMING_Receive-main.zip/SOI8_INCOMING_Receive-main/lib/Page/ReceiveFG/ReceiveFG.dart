import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:standard_package_rm/Page/App_Bar/App_Bar.dart';
import 'package:standard_package_rm/Page/MenuSelect/data/MenuSelectPage_Data.dart';
import 'package:standard_package_rm/Page/ReceiveFG/data/ReceiveFG_data.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:standard_package_rm/global_var.dart';
//import 'package:image_picker/image_picker.dart';

late BuildContext contextreceiveFG;

class ReceiveFG extends StatelessWidget {
  const ReceiveFG({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ManageDataReceiveFG>(
          create: (BuildContext context) => ManageDataReceiveFG(),
        ),
      ],
      child: receiveFG(),
    );
  }
}

class receiveFG extends StatefulWidget {
  const receiveFG({Key? key}) : super(key: key);

  @override
  State<receiveFG> createState() => _receiveFGState();
}

String pathCSV = "";
List<ModelIncomingData> csvData = [];

TextStyle styleHeader = const TextStyle(
    fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Mitr');
TextStyle styleData = const TextStyle(
    fontSize: 14, fontWeight: FontWeight.normal, fontFamily: 'Mitr');

double swiperHeight = 320;
double swiperWidth = 450;

class _receiveFGState extends State<receiveFG> {
  @override
  void initState() {
    super.initState();
    //context.read<ManageDataReceiveFG>().add(FetchitemData());
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _saveData() {
    CoolAlert.show(
      barrierDismissible: true,
      width: 200,
      context: context,
      type: CoolAlertType.warning,
      text: 'บันทึกข้อมูล',
      confirmBtnText: 'Yes',
      cancelBtnText: 'No',
      loopAnimation: true,
      showCancelBtn: true,
      confirmBtnColor: Colors.green,
      widget: TextField(
        decoration: const InputDecoration(
            contentPadding: EdgeInsets.all(10.0), border: OutlineInputBorder()),
        onChanged: (value) {},
      ),
      onConfirmBtnTap: () {
        //dataIn[0].
        saveData();
        Navigator.pop(context);
        Navigator.pop(context);
      },
      onCancelBtnTap: () {
        Navigator.pop(context);
      },
    );
  }

  bool _checkData() {
    bool status = true;
    if (itemData[0].LotNo != "" &&
        itemData[0].ExpireDate != "" &&
        itemData[0].FifoCheck != "" &&
        itemData[0].Location != "" &&
        itemData[0].ProductNameCheck != "" &&
        itemData[0].PackSizeCheck != "" &&
        itemData[0].PictrogramCheck != "" &&
        itemData[0].AppearanceCheck != "" &&
        itemData[0].SummaryCheck != "") {
      status = true;
    } else {
      status = false;
      CoolAlert.show(
        barrierDismissible: true,
        width: 200,
        context: context,
        type: CoolAlertType.error,
        text: 'กรุณาใส่ข้อมูลให้ครบ',
        loopAnimation: true,
      );
    }
    return status;
  }

  final _formKey = GlobalKey<FormBuilderState>();
  @override
  Widget build(BuildContext context) {
    //contextreceiveFG = context;
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
    contextreceiveFG = context;
    return MaterialApp(
        scaffoldMessengerKey: _scaffoldMessengerKey,
        home: Scaffold(
            appBar: AppBar(
              backgroundColor: const Color(0xFF0b1327),
              actions: <Widget>[App_Bar()],
            ),
            key: _scaffoldKey,
            body: SingleChildScrollView(
              child: Container(
                  margin: const EdgeInsets.only(
                    top: 5,
                  ),
                  child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          if (itemData.isNotEmpty)
                            Container(
                              margin: const EdgeInsets.only(
                                left: 25,
                                right: 25,
                                top: 20,
                              ),
                              width: swiperWidth,
                              height: swiperHeight,
                              //color: Colors.red,
                              child: Swiper(
                                loop: true,
                                duration: 10,
                                autoplayDelay: 1000,
                                index: 0,
                                itemBuilder: (BuildContext context, int index) {
                                  return Container(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 15),
                                        SizedBox(
                                          width: swiperWidth,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              GestureDetector(
                                                child: Container(
                                                  //color: Colors.amber,
                                                  //width: swiperWidth - 20,
                                                  height: 300,
                                                  child: Center(
                                                      child: ShowPicture(
                                                          path: itemData[index]
                                                              .PicCode
                                                              .toString())),
                                                ),
                                                onTap: () {
                                                  showPicZoom(picture);
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                                itemCount: itemData.length,
                                pagination: const FractionPaginationBuilder(
                                    fontSize: 15,
                                    color: Colors.black,
                                    activeFontSize: 15,
                                    activeColor: Colors.black),
                                control: const SwiperControl(),
                              ),
                            ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'MATERIAL CODE',
                                style: styleHeader,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                //width: textboxSize,
                                child: Text(
                                  itemData[0].MaterialCode.toString(),
                                  style: styleData,
                                  maxLines: null,
                                ),
                              ),
                            ],
                          ),
                          space(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                //width: textboxSize,
                                child: Text(
                                  'CODE NAME',
                                  style: styleHeader,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                // width: textboxSize,
                                child: Text(
                                  itemData[0].CodeName.toString(),
                                  style: styleData,
                                  maxLines: null,
                                ),
                              ),
                            ],
                          ),
                          space(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'PRODUCT NAME',
                                style: styleHeader,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                //width: textboxSize,
                                child: Text(
                                  itemData[0].ProductName.toString(),
                                  style: styleData,
                                  maxLines: null,
                                ),
                              ),
                            ],
                          ),
                          space(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'LAST LOT RECEIVE',
                                style: styleHeader,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                //width: textboxSize,
                                child: Text(
                                  itemData[0].ProductName.toString(),
                                  style: styleData,
                                  maxLines: null,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 25,
                          ),
//---------------------------------------------------------------------------------
                          dataTextIn("LOT NO", "LTN"),
                          Row(
                            children: [
                              SizedBox(
                                width: swiperWidth / 2 + 20,
                                child: Row(
                                  children: [
                                    const SizedBox(width: 50),
                                    Text(
                                      "EXPIRE DATE",
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 160,
                                child: FormBuilderDateTimePicker(
                                  decoration: formField(),
                                  //initialValue: DateTime.parse(
                                  //   searchOption[0].receiveDateS),
                                  inputType: InputType.date,
                                  name: 'expireDate',
                                  onChanged: (value) {
                                    itemData[0].ExpireDate = value.toString();
                                  },
                                ),
                              )
                            ],
                          ),

                          dataChoiseIn("FIFO CHECK", "FFC"),
                          dataTextIn("STORAGE LOCATION", "LCT"),
                          dataChoiseIn("PRODUCT NAME", "PDC"),
                          dataChoiseIn("PICTROGRAM", "PTGC"),
                          dataChoiseIn("PACKAGE SIZE", "PSC"),
                          dataChoiseIn("PACKAGE APPEARANCE", "APC"),
                          dataChoiseIn("SUMMARY CHECK", "SMC"),
                          Row(
                            children: [
                              SizedBox(
                                width: swiperWidth / 2 + 20,
                                child: Row(
                                  children: [
                                    const SizedBox(width: 50),
                                    Text(
                                      "PICTURE",
                                      style: styleHeader,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 160,
                                child: Container(
                                  child: InkWell(
                                    onTap: () async {
                                      final ImagePicker _picker = ImagePicker();
                                      final XFile? photo =
                                          await _picker.pickImage(
                                              source: ImageSource.camera);
                                      String imagepath = photo!.path;
                                      //image path, you can get it with image_picker package
                                      print(imagepath);
                                      File imagefile = File(
                                          imagepath); //convert Path to File
                                      Uint8List imagebytes = await imagefile
                                          .readAsBytes(); //convert to bytes
                                      String base64string = base64.encode(
                                          imagebytes); //convert bytes to base64 string
                                      print(base64string);
                                    },
                                    child: const Icon(
                                      Icons.camera,
                                      color: Colors.black,
                                      size: 20.0,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: swiperWidth,
                                child: Center(
                                  child: IconButton(
                                    icon: const Icon(
                                      Icons.save,
                                      color: Colors.green,
                                    ),
                                    onPressed: () {
                                      if (_checkData()) _saveData();
                                      //tempSave(index);
                                    },
                                  ),
                                ),
                              ),

                              /* Container(
                                width: 50,
                                child: Center(
                                  child: IconButton(
                                    icon: const Icon(
                                      Icons.cancel,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      rejectRawMat();
                                      //tempSave(index);
                                    },
                                  ),
                                ),
                              ), */
                            ],
                          )
                          /* if (itemData.isEmpty)
                            Container(
                              margin: const EdgeInsets.only(
                                  left: 25, right: 25, top: 25, bottom: 15),
                              width: swiperWidth,
                              height: swiperHeight,
                              child: const Text('NOT FOUND DATA',
                                  style: TextStyle(
                                      fontSize: 40,
                                      fontWeight: FontWeight.normal,
                                      fontFamily: 'Mitr')),
                            ), */
                        ],
                      )))),
            )));
  }

  InputDecoration formField() {
    return const InputDecoration(
        contentPadding: EdgeInsets.all(10),
        border: OutlineInputBorder(gapPadding: 8));
  }

  Row dataChoiseIn(String name, String indexName) {
    return Row(
      children: [
        SizedBox(
          width: swiperWidth / 2 + 20,
          child: Row(
            children: [
              const SizedBox(width: 50),
              Text(
                name,
                style: styleHeader,
              ),
            ],
          ),
        ),
        SizedBox(
          width: 160,
          child: ChoiceChip(index: 0, name: indexName),
        )
      ],
    );
  }

  Row dataTextIn(String name, String indexName) {
    return Row(
      children: [
        SizedBox(
          width: swiperWidth / 2 + 20,
          child: Row(
            children: [
              const SizedBox(width: 50),
              Text(
                name,
                style: styleHeader,
              ),
            ],
          ),
        ),
        SizedBox(
          width: 160,
          child: TextIn(index: 0, name: indexName),
        )
      ],
    );
  }

  SizedBox space() {
    return const SizedBox(
      height: 4,
    );
  }

  SizedBox spaceHor() {
    return const SizedBox(
      width: 25,
    );
  }

  double textboxSize = 200;
  Future<void> showPicZoom(String pic) {
    return showDialog(
      context: context,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        var outputAsUint8List;
        outputAsUint8List = base64.decode(pic);
        return Dialog(
          backgroundColor: Colors.transparent,
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: Container(
              alignment: FractionalOffset.center,
              height: 1000,
              width: 550,
              padding: const EdgeInsets.all(20.0),
              child: SizedBox(
                child: outputAsUint8List != null
                    ? Image.memory(outputAsUint8List!,
                        //width: 250, height: 250,
                        fit: BoxFit.cover)
                    : Container(),
              ),
            ),
          ),
        );
      },
    );
  }
}

class ShowPicture extends StatefulWidget {
  String path = "";
  ShowPicture({
    required this.path,
  });

  @override
  State<StatefulWidget> createState() => ShowPictureState();
}

class ShowPictureState extends State<ShowPicture> {
  late bool isShowingMainData;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: getPicture(widget.path),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data != 0) {
              var outputAsUint8List;
              outputAsUint8List = base64.decode(picture);
              return Container(
                width: 300,
                child: outputAsUint8List != null
                    ? Image.memory(outputAsUint8List!,
                        //width: 250, height: 250,
                        fit: BoxFit.cover)
                    : Container(),
              );
            } else {
              return Text("PICTURE NOT FOUND");
            }
          } else if (snapshot.hasError) {
            return Text(snapshot.error.toString());
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        });
  }
}

class TextIn extends StatefulWidget {
  int index;
  String name;
  TextIn({Key? key, required this.index, required this.name}) : super(key: key);

  @override
  State<TextIn> createState() => _TextInState();
}

class _TextInState extends State<TextIn> {
  @override
  Widget build(BuildContext context) {
    int index = widget.index;
    String name = widget.name;
    String status = "";
    return SizedBox(
      //height: 35,
      child: FormBuilderTextField(
        /*  decoration: const InputDecoration(
            constraints: BoxConstraints(maxHeight: 50),
            contentPadding: EdgeInsets.all(0),
            border: OutlineInputBorder(gapPadding: 1)
            //border: InputBorder.none,
            ), */
        decoration: InputDecoration(
            contentPadding: EdgeInsets.all(10),
            border: OutlineInputBorder(gapPadding: 8)),
        name: name + index.toString(),
        onChanged: (dynamic val) {
          if (name == 'LTN') {
            itemData[index].LotNo = val.toString();
          } else if (name == 'LCT') {
            itemData[index].Location = val.toString();
          }
        },
      ),
    );
  }
}

class ChoiceChip extends StatefulWidget {
  int index;
  String name;
  ChoiceChip({Key? key, required this.index, required this.name})
      : super(key: key);

  @override
  State<ChoiceChip> createState() => _ChoiceChipState();
}

class _ChoiceChipState extends State<ChoiceChip> {
  @override
  Widget build(BuildContext context) {
    int index = widget.index;
    String name = widget.name;
    String status = "";
    if (name == 'FFC') {
      status = itemData[index].FifoCheck;
    } else if (name == 'PDC') {
      status = itemData[index].ProductNameCheck;
    } else if (name == 'PSC') {
      status = itemData[index].PackSizeCheck;
    } else if (name == 'PTGC') {
      status = itemData[index].PictrogramCheck;
    } else if (name == 'APC') {
      status = itemData[index].AppearanceCheck;
    } else if (name == 'SMC') {
      status = itemData[index].SummaryCheck;
    }
    return SizedBox(
      //height: 35,
      child: FormBuilderChoiceChip<String>(
        visualDensity: const VisualDensity(
          horizontal: 0,
          vertical: 0,
        ),
        //materialTapTargetSize: MaterialTapTargetSize,
        alignment: WrapAlignment.start,
        //alignment: WrapAlignment.center,
        padding: EdgeInsets.only(left: 25, right: 25),
        selectedColor: (() {
          if (status == "OK") {
            return Colors.green;
          } else {
            return Colors.red;
          }
        }()),
        labelPadding: const EdgeInsets.all(0),
        decoration: const InputDecoration(
          constraints: BoxConstraints(maxHeight: 50),
          contentPadding: EdgeInsets.all(0),
          //border: OutlineInputBorder(gapPadding: -5)
          border: InputBorder.none,
        ),
        avatarBorder: const CircleBorder(side: BorderSide.none),
        //shape: StadiumBorder(side: BorderSide()),
        name: name + index.toString(),
        spacing: 20,
        options: const [
          FormBuilderChipOption(
            value: "OK",
          ),
          FormBuilderChipOption(
            value: "NG",
          ),
          //FormBuilderChipOption(value: "NG")
        ],
        onChanged: (dynamic val) {
          if (name == 'FFC') {
            itemData[index].FifoCheck = val.toString();
          } else if (name == 'PDC') {
            itemData[index].ProductNameCheck = val.toString();
          } else if (name == 'PSC') {
            itemData[index].PackSizeCheck = val.toString();
          } else if (name == 'PTGC') {
            itemData[index].PictrogramCheck = val.toString();
          } else if (name == 'APC') {
            itemData[index].AppearanceCheck = val.toString();
          } else if (name == 'SMC') {
            itemData[index].SummaryCheck = val.toString();
          }

          setState(() {});
        },
      ),
    );
  }
}
