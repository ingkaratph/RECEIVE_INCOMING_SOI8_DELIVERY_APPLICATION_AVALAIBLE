import 'dart:async';
//import 'dart:html';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:shared_preferences/shared_preferences.dart';
//----------------------------------------------------------------
import 'package:http/http.dart' as http;
import 'package:standard_package_rm/Global/global_var.dart';
import 'package:standard_package_rm/Page/MenuSelect/data/MenuSelectPage_Data.dart';
import 'package:standard_package_rm/global_var.dart';

abstract class ReceiveFGEvent {}

class FetchincomingData extends ReceiveFGEvent {}

class SearchincomingData extends ReceiveFGEvent {}

// ignore: camel_case_types
class ManageDataReceiveFG
    extends Bloc<ReceiveFGEvent, List<ModelIncomingData>> {
  ManageDataReceiveFG() : super([ModelIncomingData()]) {
    //on<ClearState>((event, emit) => _ClearState(>));]

    // ignore: void_checks
    on<FetchincomingData>((event, emit) {
      return _FetchincomingData(event, emit);
    });
    // ignore: void_checks
    on<SearchincomingData>((event, emit) {
      return _SearchincomingData(event, emit);
    });
  }
}

List<ModelIncomingData> incomingData = [];
// ignore: non_constant_identifier_names
Future<List<ModelIncomingData>> _FetchincomingData(event, emit) async {
  print('in Fetch data');
  Map<String, String> qParams = {
    // 'reqNo': reqNo,
  };
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_FetchincomingData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    if (response.statusCode == 200) {
      incomingData = ModelIncomingDataFromJson(response.body);
      emit(incomingData);
      return incomingData;
    } else {
      emit(incomingData);
      return incomingData;
    }
  } on TimeoutException catch (e) {
    print(e);
    emit(incomingData);
    return incomingData;
  } on Error catch (e) {
    print(e);
    emit(incomingData);
    return incomingData;
  }
}

String SearchOption = "";
Future<List<ModelIncomingData>> _SearchincomingData(event, emit) async {
  print('in SearchincomingData data');
  Map<String, String> qParams = {
    'SearchOption': SearchOption,
  };
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_SearchincomingData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    if (response.statusCode == 200) {
      print('in2');
      incomingData = ModelIncomingDataFromJson(response.body);
      emit(incomingData);
      return incomingData;
    } else {
      return incomingData;
    }
  } on TimeoutException catch (e) {
    return incomingData;
  } on Error catch (e) {
    return incomingData;
  }
}

String picture = "";
Future getPicture(String path) async {
  Map<String, String> qParams = {
    'path': path,
  };
  print("in searchPicture $path");
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_LoadPicture"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      picture = response.body;
      print("in searchPicture response complete");
      return 1;
    } else {
      print("where is my server");
      return 0;
    }
  } catch (e) {
    print(e);
  }
}

List<ModelIncomingData> accpetData = [];

Future saveData() async {
  Map<String, String> qParams = {
    'user': userName,
    'data': ModelIncomingDataToJson(itemData),
  };
  print("in saveData ");
  EasyLoading.show(status: 'loading...');
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_saveData"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      EasyLoading.dismiss();
      return 1;
    } else {
      EasyLoading.dismiss();
      CoolAlert.show(
        barrierDismissible: true,
        width: 200,
        context: contextBG,
        type: CoolAlertType.error,
        text: 'บันทึกข้อมูลไม่ผ่าน โปรดบันทึกใหม่',
      );
      return 0;
    }
  } catch (e) {
    EasyLoading.dismiss();
    CoolAlert.show(
      barrierDismissible: true,
      width: 200,
      context: contextBG,
      type: CoolAlertType.error,
      text: 'บันทึกข้อมูลไม่ผ่าน โปรดบันทึกใหม่',
    );
    print(e);
  }
}

List<ModelIncomingData> rejectData = [];

Future saveRejectRawMat() async {
  Map<String, String> qParams = {
    'user': userName,
    'rejectData': ModelIncomingDataToJson(rejectData),
  };
  print("in saveRejectRawMat ");
  try {
    final response = await http
        .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_saveRejectRawMat"),
            body: qParams)
        .timeout(Duration(seconds: 15));
    //print(response.body);
    if (response.statusCode == 200) {
      picture = response.body;
      print("in SaveRecheckData response complete");
      return 1;
    } else {
      print("where is my server");
      return 0;
    }
  } catch (e) {
    print(e);
  }
}
