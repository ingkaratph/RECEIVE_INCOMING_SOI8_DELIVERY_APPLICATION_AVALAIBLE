import 'dart:async';
import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cool_alert/cool_alert.dart';
//----------------------------------------------------------------
import 'package:http/http.dart' as http;
import 'package:standard_package_rm/Global/global_var.dart';

/* Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
late Future<String> token;

abstract class Login_Event {}

class Login extends Login_Event {}

class Logout extends Login_Event {}

// ignore: camel_case_types
class Login_Bloc extends Bloc<Login_Event, String> {
  Login_Bloc() : super("") {
    //on<ClearState>((event, emit) => _ClearState(>));]

    // ignore: void_checks
    on<Login>((event, emit) {
      return _Login(event, emit);
    });
    // ignore: void_checks
    /* on<Logout>((event, emit) {
      return _SearchincomingData(event, emit);
    }); */
  }
} */

String User = "";
String Password = "";
Future<String> Login() async {
  Map<String, String> qParams = {
    'User': User,
    'Password': Password,
  };
  EasyLoading.show(status: 'loading...');
  print("_Login");
  final response = await http
      .post(Uri.parse("$url/SOI8_Incoming_PackingSTD_Login"), body: qParams)
      .timeout(Duration(seconds: 15));
  var databuff;
  if (response.statusCode == 200) {
    EasyLoading.dismiss();
    if (response.body != "error") {
      databuff = jsonDecode(response.body);
      if (databuff.length > 0) {
        userName = databuff[0]['StrOper'];
      }
      print(userName);
    } else {
      print("wrong password");
      userName = '';
      CoolAlert.show(
        width: 150,
        context: contextBG,
        type: CoolAlertType.error,
        title: 'Oops...',
        text: 'INVALID USER OR PASSWORD',
        loopAnimation: false,
      );
    }
  } else {
    EasyLoading.dismiss();
    userName = '';
    CoolAlert.show(
      width: 150,
      context: contextBG,
      type: CoolAlertType.error,
      title: 'Oops...',
      text: 'TIME OUT',
      loopAnimation: false,
    );
    return "";
  }
  EasyLoading.dismiss();
  return "";
}
