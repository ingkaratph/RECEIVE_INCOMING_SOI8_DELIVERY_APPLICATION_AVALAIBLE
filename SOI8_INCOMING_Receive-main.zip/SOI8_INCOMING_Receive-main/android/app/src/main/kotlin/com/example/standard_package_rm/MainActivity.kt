package com.example.standard_package_rm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
